main()
{
    char a,b,c;
    a='q';
    b='w';
    c='e';
}