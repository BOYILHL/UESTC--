main()
{
    int a,b;
    int w[2];
    a=1;
    b=2;
    w[0]=a;
    w[1]=b;
}