main()
{
	int i;
	i=1;

	while(i<10)
	{ 
		i=i+1;
	}
    
    i=999;
}

