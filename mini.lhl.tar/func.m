main()
{
	int  a , b , c , d,g ;
	b = 1;
    c = 2;
    d = b + c;
    g = max(c,d);
    a = - b * c + d ;
    if ( a ) { a = - b * c ; }

    d = 999;
}

