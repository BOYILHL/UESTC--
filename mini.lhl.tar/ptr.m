main()
{
    int a,b,c;
    a=3;
    b=4;
    c=a+b;
}