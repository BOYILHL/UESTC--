main()
{
    char a[4];
    a[0]='e';
    a[1]='s';
    a[2]='c';
    a[3]=a[2];
}