main()
{
    int a,b;
    int *p,*q;
    a=1;
    b=2;
    p=&a;
    q=&b;
}