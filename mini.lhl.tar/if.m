main()
{
	int  a , b , c ;
    int w[2];
    w[0]=1;
    w[1]=2;
	b = 1;
    c = 2;
    a = 1 ;

    if ( a==w[0] && c==w[1] ) { a = 4 ; }
    if ( b==w[0] || a==w[1] ) { a = 5 ; }
    if ( !d ) { a = 6 ; }
}

