main()
{
    int w[20];
    int a,b,c;
    char d,e,f;
    a=1;
    b=a+1;
    c=b+1;
    d='A';
    e='B'+1;
    f=d+c;

    for (a=1; a<=10; a=a+1)
    {
        f=f+1;
        e=e+d;
    }
}