main()
{
    int a,b,c;
    int w[4];
    a=10;
    b=9;
    c=8;
    w[0]=a;
    w[1]=b;
    w[2]=c;
    w[3]=w[2];
}