main()
{
    int w[2];
    char m[5];
    int a,b,c;
    char e,f,g;
    a=10;
    w[0]=a;
    w[1]=w[0];
    b=w[1]+w[0];
    c=b*w[1];
    m[0]='a';
    m[1]='b'+1;
    m[2]=m[0]+m[1];
    e='e';
    f='f';
    g=e+f;
    m[3]=m[1]+1;
    m[3]=g-1;
}